package com.hackathon.smokesuite;

import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class SmokeTesting {
	WebDriver driver;
	Properties p = new Properties();
	static ExtentReports smokereport;
	static ExtentTest smoketest;
	static List<WebElement> path;
	static WebDriverWait wait = null;
	WebElement emailvalid;
	CharSequence value;
	// Declare An Excel Work Book
	HSSFWorkbook workbook;
	// Declare An Excel Work Sheet
	HSSFSheet sheet;
	// Declare A Map Object To Hold TestNG Results
	Map<String, Object[]> TestNGResults;

	@BeforeClass(alwaysRun = true)
	public void suiteSetUp() {

		// create a new work book
		workbook = new HSSFWorkbook();
		// create a new work sheet
		sheet = workbook.createSheet("smoke Result Summary");
		TestNGResults = new LinkedHashMap<String, Object[]>();
		// add test result excel file column header
		// write the header in the first row
		TestNGResults.put("1", new Object[] { "Test Step No.", "Action", "Expected Output", "Actual Output" });

	}

	@AfterClass(alwaysRun = true)
	public void suiteTearDown() {
		// write excel file and file name is SaveTestNGResultToExcel.xls
		Set<String> keyset = TestNGResults.keySet();
		int rownum = 0;

		for (String key : keyset) {
			Row row = sheet.createRow(rownum++);
			Object[] objArr = TestNGResults.get(key);
			int cellNum = 0;

			for (Object obj : objArr) {
				Cell cell = row.createCell(cellNum++);
				if (obj instanceof Date)
					cell.setCellValue((Date) obj);
				else if (obj instanceof Boolean)
					cell.setCellValue((Boolean) obj);
				else if (obj instanceof String)
					cell.setCellValue((String) obj);
				else if (obj instanceof Double)
					cell.setCellValue((Double) obj);
			}
		}

		try {
			FileOutputStream out = new FileOutputStream(new File("SaveSmokeResultToExcel.xls"));
			workbook.write(out);
			out.close();
			// System.out.println("Successfully saved Selenium WebDriver TestNG result to
			// Excel File!!!");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@BeforeSuite(alwaysRun = true)
	public static void startTest() {
		smokereport = new ExtentReports(System.getProperty("user.dir") + "\\SmokeExtentReportResults.html");
		smoketest = smokereport.startTest("SmokeTesting");
	}

	@BeforeTest(alwaysRun = true)
	@Parameters({ "browser" })
	public void differentBrowser(String browser) throws IOException, InterruptedException {

		if (browser.equalsIgnoreCase("Firefox")) {
			// to invoke firefox browser
			System.setProperty("webdriver.gecko.driver", ".\\src\\main\\resources\\driver\\geckodriver.exe");
			driver = new FirefoxDriver();
			Thread.sleep(1000);
		} else if (browser.equalsIgnoreCase("chrome")) {
			// to invoke chrome browser
			System.setProperty("webdriver.chrome.driver", ".\\src\\main\\resources\\driver\\chromedriver.exe");
			driver = new ChromeDriver();
			Thread.sleep(1000);

		} else {
			throw new IllegalArgumentException("Invalid browser value!!");
		}

		// Thread.sleep(1000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		// to open udemy web application
		driver.get("https://www.udemy.com");
		driver.manage().window().maximize();
		// driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.manage().deleteAllCookies();
		InputStream file = new FileInputStream(
				".\\src\\main\\java\\com\\hackathon\\smokesuite\\smoketesting.properties");
		p.load(file);

	}

	@Test(priority = 1)
	public void directedToURL() throws InterruptedException, IOException {

		Thread.sleep(1000);
		driver.get(p.getProperty("url"));
		driver.manage().window().maximize();
		wait = new WebDriverWait(driver, 2);

		// to inspect and get the website logo
		String expected = wait.until(
				ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='c_header__logo-container']")))
				.getText();
		String actual = driver.findElement(By.xpath("//div[@class='c_header__logo-container']")).getText();
		try {
			if (expected.equalsIgnoreCase(actual)) {
				smoketest.log(LogStatus.PASS, "Test passed- directed to url page");
				TestNGResults.put("0", new Object[] { 1d, "corresponding url", "open the url page", "Pass" });
			} else {
				smoketest.log(LogStatus.FAIL, "Test Failed- directed to url page");
				TestNGResults.put("0", new Object[] { 1d, "corresponding url ", "open the url page", "Fail" });
			}
		} catch (NullPointerException e) {

		}

	}

	@Test(priority = 2)
	public void searchForCourseDetails() throws InterruptedException, IOException {
		driver.get(p.getProperty("url"));

		// to check if the search box is accepting "web development" courses to search

		// to enter course name from drop down list
		driver.findElement(By.xpath("//*[@id=\"header-search-field\"]")).sendKeys(p.getProperty("course"));
		WebElement mouse = driver.findElement(By.xpath(
				"//div[@class='dropdown es-autocomplete es-autocomplete--primary']//button[@class='btn btn-link']"));
		mouse.click();
		wait = new WebDriverWait(driver, 2);
		String expected = wait
				.until(ExpectedConditions
						.visibilityOfElementLocated(By.xpath("//h1[contains(text(),'Web Development Courses')]")))
				.getText();
//		driver.navigate().back();
//		wait = new WebDriverWait(driver, 2);
//		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"header-search-field\"]")));

		// to enter course name through sendKeys() function
//		driver.findElement(By.xpath("//*[@id=\"header-search-field\"]")).sendKeys(p.getProperty("course"));
//		driver.findElement(By.xpath("//button[@class='btn btn-link']")).click();
		String actual = wait
				.until(ExpectedConditions
						.visibilityOfElementLocated(By.xpath("//h1[contains(text(),'Web Development Courses')]")))
				.getText();

		if (expected.equalsIgnoreCase(actual)) {
			smoketest.log(LogStatus.PASS, "Test passed- search button");
			TestNGResults.put("1", new Object[] { 2d, "search button", "corresponding page open", "Pass" });
		} else {
			smoketest.log(LogStatus.FAIL, "Test Failed- search button");
			TestNGResults.put("1", new Object[] { 2d, "search button ", "corresponding page open", "Fail" });
		}
	}

	@Test(priority = 3)
	public void filter() throws InterruptedException {
		driver.get(p.getProperty("url"));
		driver.findElement(By.xpath("//*[@id=\"header-search-field\"]")).sendKeys(p.getProperty("course"));
		driver.findElement(
				By.xpath("//*[@id=\"udemy\"]/div[2]/div[3]/div[1]/div[2]/div[3]/div/div/div/form/span/span/button"))
				.click();
		wait = new WebDriverWait(driver, 2);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.tagName("h1")));
		driver.findElement(By.xpath("//button[@class='filter-button--filter-button--y-iVA btn btn-quaternary']"))
				.click();
		driver.findElement(By.cssSelector(
				".filter--filter-container--1ftIU:nth-child(3) > .filter-option--checkbox--3Ar4b:nth-child(3) .toggle-control-label"))
				.click();
		driver.findElement(By.xpath("//button[@class='filter-button--filter-button--y-iVA btn btn-quaternary']"))
				.click();
		driver.findElement(By.cssSelector(
				".filter--filter-container--1ftIU:nth-child(4) > .filter-option--checkbox--3Ar4b:nth-child(2) .toggle-control-label"))
				.click();
		wait = new WebDriverWait(driver, 2);
		String expected = wait.until(
				ExpectedConditions.visibilityOfElementLocated(By.className("list-view-course-card--title--2pfA0")))
				.getText();
		String actual = driver.findElement(By.className("list-view-course-card--title--2pfA0")).getText();
		if (expected.equals(actual)) {
			smoketest.log(LogStatus.PASS, "Test passed- Filter");
			TestNGResults.put("2",
					new Object[] { 3d, "checking filter is working", "filters based on criteria", "Pass" });
		} else {
			smoketest.log(LogStatus.FAIL, "Test Failed- Filter");
			TestNGResults.put("2",
					new Object[] { 3d, "checking filter is working", "filters based on criteria", "Fail" });
		}

	}

	@Test(priority = 4)
	public void navigation() throws InterruptedException {
		driver.get(p.getProperty("url"));
		driver.findElement(By.xpath("//*[@id=\"header-search-field\"]")).sendKeys(p.getProperty("course"));
		driver.findElement(
				By.xpath("//*[@id=\"udemy\"]/div[2]/div[3]/div[1]/div[2]/div[3]/div/div/div/form/span/span/button"))
				.click();
		wait = new WebDriverWait(driver, 2);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.tagName("h1")));
		driver.findElement(By.xpath("//button[@class='filter-button--filter-button--y-iVA btn btn-quaternary']"))
				.click();
		driver.findElement(By.cssSelector(
				".filter--filter-container--1ftIU:nth-child(3) > .filter-option--checkbox--3Ar4b:nth-child(3) .toggle-control-label"))
				.click();
		driver.findElement(By.xpath("//button[@class='filter-button--filter-button--y-iVA btn btn-quaternary']"))
				.click();
		driver.findElement(By.cssSelector(
				".filter--filter-container--1ftIU:nth-child(4) > .filter-option--checkbox--3Ar4b:nth-child(2) .toggle-control-label"))
				.click();
		driver.findElement(By.xpath("//span[@class='pagination-next udi udi-next']")).click();
		wait = new WebDriverWait(driver, 2);
		String expected = wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("2"))).getText();
		String actual = driver.findElement(By.linkText("2")).getText();
		if (expected.equals(actual)) {
			smoketest.log(LogStatus.PASS, "Test passed- navigation");
			TestNGResults.put("3", new Object[] { 4d, "navigation", "should navigate to next page", "Pass" });
		} else {
			smoketest.log(LogStatus.FAIL, "Test failed- navigation");
			TestNGResults.put("3", new Object[] { 4d, "navigation", "should navigate to next page", "Fail" });
		}

	}

	@Test(priority = 5)
	public void signUpPage() throws IOException, InterruptedException {

		driver.get(p.getProperty("url"));

		// to click on sign up button
		driver.findElement(By.cssSelector("div:nth-child(1) > .btn-primary")).click();
		wait = new WebDriverWait(driver, 2);
		// wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id='submit-id-submit']")));

		// to enter name, email and password
		driver.findElement(By.id("id_fullname")).sendKeys(p.getProperty("fullname"));
		driver.findElement(By.id("email--1")).sendKeys(p.getProperty("email"));
		driver.findElement(By.id("password")).sendKeys(p.getProperty("password"));

		// to click on submit button
		driver.findElement(By.id("submit-id-submit")).click();
		wait = new WebDriverWait(driver, 2);

		// to inspect and get alert message
		String expected = wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("//div[contains(@class,'alert alert-danger js-error-alert')]")))
				.getText();
		String actual = driver.findElement(By.xpath("//div[contains(@class,'alert alert-danger js-error-alert')]"))
				.getText();

		if (expected.equalsIgnoreCase(actual)) {
			smoketest.log(LogStatus.PASS, "Test passed- invalid sign up details");
			TestNGResults.put("4", new Object[] { 5d, "sign up", "should display error message ", "Pass" });
		} else {
			smoketest.log(LogStatus.FAIL, "Test Failed- invalid sign up details");
			TestNGResults.put("4", new Object[] { 5d, "sign up ", "should display error message ", "Fail" });
		}

	}

	@Test(priority = 6)
	public void loginInvalidEmailInvalidPassword() throws IOException, InterruptedException {

		// driver.get("https://www.udemy.com/");
		// driver.findElement(By.xpath("//*[@id=\"udemy\"]/div[2]/div[3]/div[1]/div[4]/div[6]/div/button")).click();
		driver.get(p.getProperty("url"));
		Thread.sleep(1000);
		WebElement clickbutton = (WebElement) new WebDriverWait(driver, 10)
				.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@class='btn btn-quaternary']")));
		clickbutton.click();
		wait = new WebDriverWait(driver, 2);

		// to check for login with invalid username and invalid password
		// wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("#email--1")));
		driver.findElement(By.cssSelector("#email--1")).sendKeys(p.getProperty("email"));
		driver.findElement(By.xpath("//input[@id='id_password']")).sendKeys(p.getProperty("password"));
		driver.findElement(By.xpath("//input[@id='submit-id-submit']")).click();
		wait = new WebDriverWait(driver, 2);
		String expected = wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("//div[contains(@class,'alert alert-danger js-error-alert')]")))
				.getText();
		String actual = driver.findElement(By.xpath("//div[contains(@class,'alert alert-danger js-error-alert')]"))
				.getText();
		if (expected.equalsIgnoreCase(actual)) {
			smoketest.log(LogStatus.PASS, "Test passed- loginInvalidEmailInvalidPassword");
			TestNGResults.put("5",
					new Object[] { 6d, "loginInvalidEmailInvalidPassword", " display error message ", "Pass" });
		} else {
			smoketest.log(LogStatus.FAIL, "Test Failed- loginInvalidEmailInvalidPassword");
			TestNGResults.put("5",
					new Object[] { 6d, "loginInvalidEmailInvalidPassword ", "display error message ", "Fail" });
		}
	}

	@Test(priority = 7)
	public void close() throws IOException, InterruptedException {
		driver.get(p.getProperty("url"));
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.close();
	}

	@AfterSuite(alwaysRun = true)
	public static void endTest() {
		smokereport.endTest(smoketest);
		smokereport.flush();
	}
}