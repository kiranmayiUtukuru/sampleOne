package com.hackathon.udemy;

import org.testng.annotations.Test;
import org.testng.annotations.Test;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;

public class CourseTest {
	WebDriver driver;
	Properties p = new Properties();
	static WebDriverWait wait = null;
	private Map<String, Object> vars;

	@BeforeTest(alwaysRun = true)
	@Parameters({ "browser" })
	public void Differentbrowser(String browser) throws IOException, InterruptedException {

		if (browser.equalsIgnoreCase("Firefox")) {
			// to invoke firefox browser
			System.setProperty("webdriver.gecko.driver", ".\\src\\main\\resources\\driver\\geckodriver.exe");
			driver = new FirefoxDriver();
			Thread.sleep(1000);
		} else if (browser.equalsIgnoreCase("chrome")) {
			// to invoke chrome browser
			System.setProperty("webdriver.chrome.driver", ".\\src\\main\\resources\\driver\\chromedriver.exe");
			driver = new ChromeDriver();
			Thread.sleep(1000);

		} else {
			throw new IllegalArgumentException("Invalid browser value!!");
		}

		// Thread.sleep(1000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		// to open udemy web application
		driver.get("https://www.udemy.com");
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		InputStream file = new FileInputStream(".\\src\\main\\java\\com\\hackathon\\udemy\\course.properties");
		p.load(file);
	}

	@Test(priority = 1)
	public void courseselection() throws InterruptedException {
		driver.navigate().to("https://www.udemy.com");
		
		//driver.get(p.getProperty("url"));
		driver.findElement(By.xpath("//*[@id=\"header-search-field\"]")).sendKeys(p.getProperty("course"));
		driver.findElement(
				By.xpath("//*[@id=\"udemy\"]/div[2]/div[3]/div[1]/div[2]/div[3]/div/div/div/form/span/span/button"))
				.click();
		wait = new WebDriverWait(driver, 2);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.tagName("h1")));
		driver.findElement(By.xpath("//button[@class='filter-button--filter-button--y-iVA btn btn-quaternary']"))
				.click();
		driver.findElement(By.cssSelector(
				".filter--filter-container--1ftIU:nth-child(3) > .filter-option--checkbox--3Ar4b:nth-child(3) .toggle-control-label"))
				.click();
		driver.findElement(By.xpath("//button[@class='filter-button--filter-button--y-iVA btn btn-quaternary']"))
				.click();
		driver.findElement(By.cssSelector(
				".filter--filter-container--1ftIU:nth-child(4) > .filter-option--checkbox--3Ar4b:nth-child(2) .toggle-control-label"))
				.click();
		List<WebElement> course = driver.findElements(By.className("list-view-course-card--title--2pfA0"));
		List<WebElement> learninghours = driver.findElements(By.className("list-view-course-card--meta-item--1Pyfe"));
		List<WebElement> ratings = driver.findElements(By.className("ml5"));
		int a = 0;
		for (int i = 0; i < 2; i++) {
			wait.until(ExpectedConditions.visibilityOf(course.get(i)));

			for (int j = 1; j < 2; j++) {

				System.out.println((a + 1) + " " + course.get(i).getText() + "\n" + "learning hours   "
						+ learninghours.get(j).getText() + "\n" + "ratings   " + ratings.get(i).getText());
				a++;
			}
		}

	}

	@Test(priority = 2)
	public void testcase2() {
		driver.get(p.getProperty("url"));
		
		driver.findElement(By.xpath("//*[@id=\"header-search-field\"]")).sendKeys(p.getProperty("course"));
		driver.findElement(
				By.xpath("//*[@id=\"udemy\"]/div[2]/div[3]/div[1]/div[2]/div[3]/div/div/div/form/span/span/button"))
				.click();
		wait = new WebDriverWait(driver, 2);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.tagName("h1")));
		JavascriptExecutor js = (JavascriptExecutor) driver;
		WebElement Element = driver
				.findElement(By.xpath("//button[@class='filter-button--filter-button--y-iVA btn btn-quaternary']"));

		js.executeScript("arguments[0].scrollIntoView();", Element);
		driver.findElement(By.xpath("//button[@class='filter-button--filter-button--y-iVA btn btn-quaternary']"))
				.click();
		WebElement Element1 = driver.findElement(By.xpath("//*[@id=\"filter-form--13\"]/fieldset[4]/button"));
		js.executeScript("arguments[0].scrollIntoView();", Element1);
		driver.findElement(By.xpath("//*[@id=\"filter-form--13\"]/fieldset[4]/button")).click();
		;

		List<WebElement> language = driver.findElements(By.xpath("//fieldset[@name='Language']//parent::div"));
		int num = language.size();

		int a = 0;
		System.out.println("\n" + "\n" + "languages :");
		for (int i = 0; i < num; i++) {
			wait.until(ExpectedConditions.visibilityOf(language.get(i)));

			System.out.println((a + 1) + " " + language.get(i).getText());

			a++;

		}
		List<WebElement> level = driver.findElements(By.xpath("//fieldset[@name='Level']//parent::div"));
		int count = level.size();
		int b = 0;
		System.out.println("\n" + "\n" + "Level :");
		for (int i = 0; i < count; i++) {
			wait.until(ExpectedConditions.visibilityOf(level.get(i)));

			System.out.println(+(b + 1) + " " + level.get(i).getText());
			b++;
		}
	}

	public String waitForWindow(int timeout) {
		try {
			Thread.sleep(timeout);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		Set<String> whNow = driver.getWindowHandles();
		Set<String> whThen = (Set<String>) vars.get("window_handles");
		if (whNow.size() > whThen.size()) {
			whNow.removeAll(whThen);
		}
		return whNow.iterator().next();
	}

	@Test(priority = 3)
	public void form() throws InterruptedException {
		vars = new HashMap<String, Object>();
		driver.get(p.getProperty("url"));
		
		vars.put("window_handles", driver.getWindowHandles());
		driver.findElement(By.id("header.try-ufb")).click();
		vars.put("win8500", waitForWindow(2000));
		vars.put("root", driver.getWindowHandle());
		driver.switchTo().window(vars.get("win8500").toString());
		Thread.sleep(1000);
//		WebElement clickbutton = (WebElement) new WebDriverWait(driver, 10).until(ExpectedConditions
//				.elementToBeClickable(By.cssSelector(".mktoFieldDescriptor:nth-child(1) .mktoLabel")));
//		clickbutton.click();
		// driver.findElement(By.cssSelector("#FirstName")).click();
		driver.findElement(By.cssSelector(".mktoFieldDescriptor:nth-child(1) .mktoLabel")).click();
		driver.findElement(By.id("FirstName")).sendKeys(p.getProperty("FirstName"));
		driver.findElement(By.cssSelector(".mktoFieldDescriptor:nth-child(2) .mktoLabel")).click();
		driver.findElement(By.id("LastName")).sendKeys(p.getProperty("LastName"));
		driver.findElement(By.cssSelector(".mktoFormRow:nth-child(3) .mktoLabel")).click();
		driver.findElement(By.id("Email")).sendKeys(p.getProperty("Email"));
		driver.findElement(By.cssSelector(".mktoFormRow:nth-child(4) .mktoLabel")).click();
		driver.findElement(By.id("Title")).sendKeys(p.getProperty("Title"));
		driver.findElement(By.cssSelector(".mktoFormRow:nth-child(5) .mktoLabel")).click();
		driver.findElement(By.id("Company")).sendKeys(p.getProperty("Company"));
		driver.findElement(By.cssSelector(".mktoFormRow:nth-child(6) .mktoLabel")).click();
		driver.findElement(By.id("Phone")).sendKeys(p.getProperty("Phone"));
		driver.findElement(By.cssSelector(".mktoButton")).click();
		String errormessage = driver.findElement(By.xpath("//div[@class='tippy-content']")).getText();
		System.out.println("\n" + "\n" + "ERROR MESSAGE");
		System.out.println("Error message Displayed : " + errormessage);

	}
}