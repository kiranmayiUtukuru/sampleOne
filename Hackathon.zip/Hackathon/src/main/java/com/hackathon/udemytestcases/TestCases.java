package com.hackathon.udemytestcases;

import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class TestCases {
	WebDriver driver;
	Properties p = new Properties();
	static ExtentReports report;
	static ExtentTest test;
	static List<WebElement> path;
	static WebDriverWait wait = null;
	WebElement emailvalid;
	CharSequence value;
	// Declare An Excel Work Book
	HSSFWorkbook workbook;
	// Declare An Excel Work Sheet
	HSSFSheet sheet;
	// Declare A Map Object To Hold TestNG Results
	Map<String, Object[]> TestNGResults;

	@BeforeSuite(alwaysRun = true)
	public static void startTest() {
		report = new ExtentReports(System.getProperty("user.dir") + "\\ExtentReportResults.html");
		test = report.startTest("setuppage");
	}

	@BeforeClass(alwaysRun = true)
	public void suiteSetUp() {

		// create a new work book
		workbook = new HSSFWorkbook();
		// create a new work sheet
		sheet = workbook.createSheet("TestNG Result Summary");
		TestNGResults = new LinkedHashMap<String, Object[]>();
		// add test result excel file column header
		// write the header in the first row
		TestNGResults.put("1", new Object[] { "Test Step No.", "Action", "Expected Output", "Actual Output" });

	}

	@AfterClass(alwaysRun = true)
	public void suiteTearDown() {
		// write excel file and file name is SaveTestNGResultToExcel.xls
		Set<String> keyset = TestNGResults.keySet();
		int rownum = 0;
		for (String key : keyset) {
			Row row = sheet.createRow(rownum++);
			Object[] objArr = TestNGResults.get(key);
			int cellNum = 0;

			for (Object obj : objArr) {
				Cell cell = row.createCell(cellNum++);
				if (obj instanceof Date)
					cell.setCellValue((Date) obj);
				else if (obj instanceof Boolean)
					cell.setCellValue((Boolean) obj);
				else if (obj instanceof String)
					cell.setCellValue((String) obj);
				else if (obj instanceof Double)
					cell.setCellValue((Double) obj);
			}
		}

		try {
			FileOutputStream out = new FileOutputStream(new File("SaveTestNGResultToExcel.xls"));
			workbook.write(out);
			out.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@BeforeTest(alwaysRun = true)
	@Parameters({ "browser" })
	public void differentBrowser(String browser) throws IOException, InterruptedException {

		if (browser.equalsIgnoreCase("Firefox")) {
			// to invoke firefox browser
			System.setProperty("webdriver.gecko.driver", ".\\src\\main\\resources\\driver\\geckodriver.exe");
			driver = new FirefoxDriver();
			Thread.sleep(1000);
		} else if (browser.equalsIgnoreCase("chrome")) {
			// to invoke chrome browser
			System.setProperty("webdriver.chrome.driver", ".\\src\\main\\resources\\driver\\chromedriver.exe");
			driver = new ChromeDriver();
			Thread.sleep(1000);

		} else {
			throw new IllegalArgumentException("Invalid browser value!!");
		}

		// Thread.sleep(1000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		// to open udemy web application
		driver.get("https://www.udemy.com");
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		InputStream file = new FileInputStream(
				".\\src\\main\\java\\com\\hackathon\\udemytestcases\\testcases.properties");
		p.load(file);
	}

	@Test(priority = 1)
	public void signUpPage() throws IOException, InterruptedException {

		driver.get(p.getProperty("url"));

		// to click on sign up button
		driver.findElement(By.cssSelector("div:nth-child(1) > .btn-primary")).click();
		wait = new WebDriverWait(driver, 2);

		// to enter name, email and password
		driver.findElement(By.id("id_fullname")).sendKeys(p.getProperty("fullname"));
		driver.findElement(By.id("email--1")).sendKeys(p.getProperty("email"));
		driver.findElement(By.id("password")).sendKeys(p.getProperty("password"));

		// to click on submit button
		driver.findElement(By.id("submit-id-submit")).click();
		wait = new WebDriverWait(driver, 2);

		// to inspect and get alert message
		String expected = wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("//div[contains(@class,'alert alert-danger js-error-alert')]")))
				.getText();
		String actual = driver.findElement(By.xpath("//div[contains(@class,'alert alert-danger js-error-alert')]"))
				.getText();

		if (expected.equalsIgnoreCase(actual)) {
			test.log(LogStatus.PASS, "Test passed- invalid sign up details");
			TestNGResults.put("0", new Object[] { 1d, "sign up", "should display error message ", "Pass" });
		} else {
			test.log(LogStatus.FAIL, "Test Failed- invalid sign up details");
			TestNGResults.put("0", new Object[] { 1d, "sign up ", "should display error message ", "Fail" });
		}

	}

	@Test(priority = 2)
	public void directedToURL() throws InterruptedException {

		driver.get(p.getProperty("url"));
		driver.manage().window().maximize();
		wait = new WebDriverWait(driver, 2);

		// to inspect and get the website logo
		String expected = wait.until(
				ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='c_header__logo-container']")))
				.getText();
		String actual = driver.findElement(By.xpath("//div[@class='c_header__logo-container']")).getText();

		if (expected.equalsIgnoreCase(actual)) {
			test.log(LogStatus.PASS, "Test passed- directed to url page");
			TestNGResults.put("1", new Object[] { 2d, "corresponding url", "open the url page", "Pass" });
		} else {
			test.log(LogStatus.FAIL, "Test Failed- directed to url page");
			TestNGResults.put("1", new Object[] { 2d, "corresponding url ", "open the url page", "Fail" });
		}
	}

	@Test(priority = 3)
	public void searchForCourseDetails() throws InterruptedException, IOException {
		driver.get(p.getProperty("url"));
		Thread.sleep(1000);
		// to check if the search box is accepting "web development" courses to search
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		// to enter course name from drop down list
		driver.findElement(By.xpath("//*[@id=\"header-search-field\"]")).sendKeys(p.getProperty("course"));
		WebElement mouse = driver.findElement(By.xpath(
				"//div[@class='dropdown es-autocomplete es-autocomplete--primary']//button[@class='btn btn-link']"));
		mouse.click();
		wait = new WebDriverWait(driver, 10);
		String expected = wait
				.until(ExpectedConditions
						.visibilityOfElementLocated(By.xpath("//h1[contains(text(),'Web Development Courses')]")))
				.getText();
		driver.navigate().back();
		wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"header-search-field\"]")));

		// to enter course name through sendKeys() function
		driver.findElement(By.xpath("//*[@id=\"header-search-field\"]")).sendKeys(p.getProperty("course"));
		driver.findElement(By.xpath("//button[@class='btn btn-link']")).click();
		String actual = wait
				.until(ExpectedConditions
						.visibilityOfElementLocated(By.xpath("//h1[contains(text(),'Web Development Courses')]")))
				.getText();

		if (expected.equalsIgnoreCase(actual)) {
			test.log(LogStatus.PASS, "Test passed- search button");
			TestNGResults.put("2", new Object[] { 3d, "search button", "corresponding page open", "Pass" });
		} else {
			test.log(LogStatus.FAIL, "Test Failed- search button");
			TestNGResults.put("2", new Object[] { 3d, "search button ", "corresponding page open", "Fail" });
		}
	}

	@Test(priority = 4)
	public void courseDetails() throws IOException, InterruptedException {
		driver.get(p.getProperty("url"));

		// to check for course details
		driver.findElement(By.xpath("//input[@id='header-search-field']")).sendKeys(p.getProperty("course"));
		driver.findElement(By.xpath("//button[@class='btn btn-link']")).sendKeys(Keys.ENTER);
		wait = new WebDriverWait(driver, 2);
		String expected = wait
				.until(ExpectedConditions.visibilityOfElementLocated(
						By.xpath("//span[contains(text(),'The only course you need to learn web development')]")))
				.getText();
		driver.findElement(By.xpath("//span[contains(text(),'The only course you need to learn web development')]"))
				.click();
		String actual = wait
				.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='clp-lead__headline']")))
				.getText();
		if (expected.contains(actual)) {
			test.log(LogStatus.PASS, "Test passed- coursedetails");
			TestNGResults.put("3", new Object[] { 4d, "coursedetails", "details are same", "Pass" });
		} else {
			test.log(LogStatus.FAIL, "Test Failed- coursedetails");
			TestNGResults.put("3", new Object[] { 4d, "details are same ", "details are same", "Fail" });
		}

	}

//to check if the applications runs on different resolutions
	@Test(priority = 5)
	public void resolution() throws InterruptedException {

		// to check if the applications runs on different resolutions
		Dimension dimension = new Dimension(1280, 1024);
		driver.manage().window().setSize(dimension);
		Dimension resolution = driver.manage().window().getSize();
		Thread.sleep(2000);
		Dimension dimension2 = new Dimension(1600, 1200);
		driver.manage().window().setSize(dimension2);
		Dimension resolution2 = driver.manage().window().getSize();
		Thread.sleep(2000);
		Dimension dimension3 = new Dimension(1680, 1050);
		driver.manage().window().setSize(dimension3);
		Dimension resolution3 = driver.manage().window().getSize();
		Thread.sleep(2000);
		Dimension dimension4 = new Dimension(1900, 1200);
		driver.manage().window().setSize(dimension4);
		Dimension resolution4 = driver.manage().window().getSize();

		if ((resolution == dimension) && (resolution2 == dimension2) && (resolution3 == dimension3)
				&& (resolution4 == dimension4)) {
			test.log(LogStatus.PASS, "Test passed -resolution ");
			TestNGResults.put("4", new Object[] { 5d, "resolution", "different resolution", "Pass" });
		} else {
			test.log(LogStatus.FAIL, "Test Failed-resolution ");
			TestNGResults.put("4", new Object[] { 5d, "resolution", "different resolution", "Fail" });
		}

	}

//login-valid username and invalid password

	@Test(priority = 6)
	public void loginInvalidPassword() throws IOException, InterruptedException {

		// to check if login page is not accepting invalid password

		driver.get(p.getProperty("url"));
		Thread.sleep(1000);
		WebElement clickbutton = (WebElement) new WebDriverWait(driver, 10)
				.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@class='btn btn-quaternary']")));
		clickbutton.click();
		// wait = new WebDriverWait(driver,2);
		// wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("#email--1")));
		driver.findElement(By.cssSelector("#email--1")).sendKeys(p.getProperty("email"));
		driver.findElement(By.xpath("//input[@id='id_password']")).sendKeys(p.getProperty("password"));
		driver.findElement(By.xpath("//input[@id='submit-id-submit']")).click();
		wait = new WebDriverWait(driver, 2);
		String expected = wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("//div[contains(@class,'alert alert-danger js-error-alert')]")))
				.getText();
		String actual = driver.findElement(By.xpath("//div[contains(@class,'alert alert-danger js-error-alert')]"))
				.getText();
		if (expected.equals(actual)) {
			test.log(LogStatus.PASS, "Test passed- valid username and invalid password");
			TestNGResults.put("5", new Object[] { 6d, "valid username and invalid password",
					"should display error message ", "Pass" });
		} else {
			test.log(LogStatus.FAIL, "Test Failed- invalid username and valid password");
			TestNGResults.put("5", new Object[] { 6d, "valid username and invalid password ",
					"should display error message ", "Fail" });
		}
	}

	@Test(priority = 7)
	public void scrolling() throws IOException, InterruptedException {

		// to check if page can be scrolled up and down
		JavascriptExecutor jse = ((JavascriptExecutor) driver);
		Object down = jse.executeScript("window.scrollTo(0, document.body.scrollHeight)");
		Object up = jse.executeScript("window.scrollTo(0,document.body.scrollTop)");
		if (down != jse.executeScript("window.scrollTo(0, document.body.scrollHeight)")
				&& (up != jse.executeScript("window.scrollTo(0, document.body.scrollTop)"))) {
			test.log(LogStatus.FAIL, "Test Failed");
			TestNGResults.put("6", new Object[] { 7d, "Scrolling", "page should scroll up and down", "Fail" });
		} else {
			test.log(LogStatus.PASS, "Test passed");
			TestNGResults.put("6", new Object[] { 7d, "Scrolling", "page should scroll up and down", "Pass" });
		}

	}

	@Test(priority = 8)
	public void pageTitle() throws IOException, InterruptedException {
		// InputStream file = new
		// FileInputStream(".\\src\\main\\java\\udemy\\setuppage.properties");
		// p.load(file);

		// to check for page title
		String actualTitle = driver.getTitle();
		String expectedTitle = p.getProperty("title");
		try {
			if (actualTitle.equalsIgnoreCase(expectedTitle)) {
				test.log(LogStatus.PASS, "Test passed- Title matched");
				TestNGResults.put("7", new Object[] { 8d, "page title ", "should display title", "Pass" });
			} else {
				test.log(LogStatus.FAIL, "Test Failed-Title didn't match");
				TestNGResults.put("7", new Object[] { 8d, "page title", "should display title", "Fail" });
			}
		} catch (NullPointerException e) {
			System.out.print("NullPointerException Caught");
		}
		Thread.sleep(1000);
	}

	@Test(priority = 9)
	public void pageNavigation() throws IOException {

		driver.get(p.getProperty("url"));
		driver.findElement(By.xpath("//*[@id=\"header-search-field\"]")).sendKeys(p.getProperty("course"));
		driver.findElement(
				By.xpath("//*[@id=\"udemy\"]/div[2]/div[3]/div[1]/div[2]/div[3]/div/div/div/form/span/span/button"))
				.click();
		wait = new WebDriverWait(driver, 2);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.tagName("h1")));
		driver.findElement(By.xpath("//button[@class='filter-button--filter-button--y-iVA btn btn-quaternary']"))
				.click();
		driver.findElement(By.cssSelector(
				".filter--filter-container--1ftIU:nth-child(3) > .filter-option--checkbox--3Ar4b:nth-child(3) .toggle-control-label"))
				.click();
		driver.findElement(By.xpath("//button[@class='filter-button--filter-button--y-iVA btn btn-quaternary']"))
				.click();
		driver.findElement(By.cssSelector(
				".filter--filter-container--1ftIU:nth-child(4) > .filter-option--checkbox--3Ar4b:nth-child(2) .toggle-control-label"))
				.click();
		driver.findElement(By.xpath("//span[@class='pagination-next udi udi-next']")).click();
		wait = new WebDriverWait(driver, 2);
		String expected = wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("2"))).getText();
		String actual = driver.findElement(By.linkText("2")).getText();
		if (expected.equals(actual)) {
			test.log(LogStatus.PASS, "Test passed- navigation");
			TestNGResults.put("8", new Object[] { 9d, "navigation", "should navigate to next page", "Pass" });
		} else {
			test.log(LogStatus.FAIL, "Test Failed- navigation");
			TestNGResults.put("8", new Object[] { 9d, "navigation ", "should navigate to next page ", "Fail" });
		}

	}

	@Test(priority = 10)
	public void image() throws IOException {

		boolean imagepresent = driver.findElement(By.xpath("//img[@class='udemy-logo']")).isDisplayed();

		if (!imagepresent) {
			test.log(LogStatus.FAIL, "Test Failed- Image not displayed");
			TestNGResults.put("9", new Object[] { 10d, "verify the logo", "image should display", "Fail" });

		} else {
			test.log(LogStatus.PASS, "Test passed- Image displayed");

			TestNGResults.put("9", new Object[] { 10d, "verify the logo", "image should display", "Pass" });

		}

	}

	@Test(priority = 11)
	public void filter() throws IOException {
		driver.get(p.getProperty("url"));
		// to apply course condition filters
		driver.findElement(By.xpath("//*[@id=\"header-search-field\"]")).sendKeys(p.getProperty("course"));
		driver.findElement(
				By.xpath("//*[@id=\"udemy\"]/div[2]/div[3]/div[1]/div[2]/div[3]/div/div/div/form/span/span/button"))
				.click();
		wait = new WebDriverWait(driver, 2);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.tagName("h1")));
		driver.findElement(By.xpath("//button[@class='filter-button--filter-button--y-iVA btn btn-quaternary']"))
				.click();
		driver.findElement(By.cssSelector(
				".filter--filter-container--1ftIU:nth-child(3) > .filter-option--checkbox--3Ar4b:nth-child(3) .toggle-control-label"))
				.click();
		driver.findElement(By.xpath("//button[@class='filter-button--filter-button--y-iVA btn btn-quaternary']"))
				.click();
		driver.findElement(By.cssSelector(
				".filter--filter-container--1ftIU:nth-child(4) > .filter-option--checkbox--3Ar4b:nth-child(2) .toggle-control-label"))
				.click();
		wait = new WebDriverWait(driver, 2);
		String expected = wait.until(
				ExpectedConditions.visibilityOfElementLocated(By.className("list-view-course-card--title--2pfA0")))
				.getText();
		String actual = driver.findElement(By.className("list-view-course-card--title--2pfA0")).getText();
		if (expected.equals(actual)) {
			test.log(LogStatus.PASS, "Test passed- Filter");
			TestNGResults.put("10",
					new Object[] { 11d, "checking filter is working", "filters based on criteria", "Pass" });
		} else {
			test.log(LogStatus.FAIL, "Test Failed- Filter");
			TestNGResults.put("10",
					new Object[] { 11d, "checking filter is working", "filters based on criteria", "Fail" });
		}

	}

	@Test(priority = 12)
	public void resultsCount() throws InterruptedException {
		driver.get(p.getProperty("url"));

		// to count the number of resulting courses
		driver.findElement(By.xpath("//input[@id='header-search-field']")).sendKeys(p.getProperty("course"));
		driver.findElement(By.xpath("//button[@class='btn btn-link']")).sendKeys(Keys.ENTER);
		wait = new WebDriverWait(driver, 2);
		wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("//h4[contains(text(),'The Web Developer Bootcamp')]")));

		WebElement mobile = driver.findElement(By.xpath("//h4[contains(text(),'The Web Developer Bootcamp')]"));
		mobile.getSize();
		if (mobile.getSize() == mobile.getSize()) {
			test.log(LogStatus.FAIL, "Test Failed- counting of the course ");
			TestNGResults.put("11",
					new Object[] { 12d, "checking the number of course displayed", "same number of course", "Fail" });

		} else {
			test.log(LogStatus.PASS, "Test passed- counting of the course ");
			TestNGResults.put("11",
					new Object[] { 12d, "checking the number of course displayed", "same number of course", "Pass" });
		}

	}

///	login- valid username and valid password

	@Test(enabled = false)
	public void login() throws IOException {
		driver.get("https://www.udemy.com/");
		driver.findElement(By.xpath("//button[@class='btn btn-quaternary']")).click();
		driver.findElement(By.xpath("//*[@id=\"email--1\"]")).sendKeys("tntharun17399@gmail.com");
		driver.findElement(By.xpath("//input[@id='id_password']")).sendKeys("udemy123");
		driver.findElement(By.xpath("//input[@id='submit-id-submit']")).click();
		wait = new WebDriverWait(driver, 2);
		String expected = wait.until(ExpectedConditions.visibilityOfElementLocated(
				By.xpath("//a[@id='header.profile']//div[@class='user-avatar__inner fx-c']"))).getText();
		String actual = driver.findElement(By.xpath("//a[@id='header.profile']//div[@class='user-avatar__inner fx-c']"))
				.getText();
		if (expected.equalsIgnoreCase(actual)) {
			test.log(LogStatus.PASS, "Test passed- valid username and valid password");
			TestNGResults.put("1", new Object[] { 3d, "Click Login and verify ", "Login success", "Pass" });
		} else {
			test.log(LogStatus.FAIL, "Test Failed- valid username and valid password");
			TestNGResults.put("4", new Object[] { 3d, "Click Login and verify ", "Login fail ", "Fail" });
		}

	}

	@Test(enabled = false)
	public void logout() throws IOException {

		wait.until(ExpectedConditions.visibilityOfElementLocated(
				By.xpath("//a[@id='header.profile']//div[@class='user-avatar__inner fx-c']")));
		Actions actions = new Actions(driver);
		WebElement target = driver
				.findElement(By.xpath("//a[@id='header.profile']//div[@class='user-avatar__inner fx-c']"));
		actions.moveToElement(target).perform();
		WebElement subtarget = driver.findElement(By.xpath("//a[contains(text(),'Log out')]"));
		subtarget.click();
		wait = new WebDriverWait(driver, 2);
		String expected = wait
				.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@class='btn btn-quaternary']")))
				.getText();
		String actual = driver.findElement(By.xpath("//button[@class='btn btn-quaternary']")).getText();
		if (expected.equalsIgnoreCase(actual)) {
			test.log(LogStatus.PASS, "Test passed- logout");
			TestNGResults.put("10", new Object[] { 9d, "logout", "back to home page", "Pass" });
		} else {
			test.log(LogStatus.FAIL, "Test Failed- logout");
			TestNGResults.put("10", new Object[] { 9d, "logout", "back to home page", "Fail" });
		}
	}

	@Test(priority = 13)
	public void forgotPassword() throws IOException, InterruptedException {
		String email = "tntharun17399@gmail.com";
		driver.get(p.getProperty("url"));

		// to check if forgot password option is working

		Thread.sleep(1000);
		WebElement clickbutton = (WebElement) new WebDriverWait(driver, 5)
				.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@class='btn btn-quaternary']")));
		clickbutton.click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//a[@class='forgot-password-link']")).click();
		// driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@name='email']")).sendKeys(email);
		// driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(1000);
		driver.findElement(By.xpath("//button[contains(.,'Reset Password')]")).click();
		Thread.sleep(1000);
		WebElement msg = driver.findElement(By.cssSelector(".content > div:nth-child(1)"));
		if (msg != null) {
			test.log(LogStatus.PASS, "Test passed- forgot password");
			TestNGResults.put("12", new Object[] { 13d, "forgot password", "display message", "Pass" });
		} else {
			test.log(LogStatus.FAIL, "Test Failed- logout");
			TestNGResults.put("12", new Object[] { 13d, "forgot password", "display message", "Fail" });
		}

	}

	@Test(priority = 14)
	public void signupFieldValidationEmail() throws InterruptedException {
		// String regex = "^(.+)@(.+)$";
		driver.get(p.getProperty("url"));
		// to sign up using valid email
		Thread.sleep(1000);
		// Actions act = new Actions(driver);
		// act.moveToElement(By.xpath("//*[@id=\"udemy\"]/div[2]/div[3]/div[1]/div[4]/div[7]/div/button")).click().perform();
		WebElement clickbutton = (WebElement) new WebDriverWait(driver, 10).until(ExpectedConditions
				.elementToBeClickable(By.xpath("//*[@id=\"udemy\"]/div[2]/div[3]/div[1]/div[4]/div[7]/div/button")));
		clickbutton.click();
		// driver.findElement(By.xpath("//*[@id=\"udemy\"]/div[2]/div[3]/div[1]/div[4]/div[7]/div/button")).click();
		// wait = new WebDriverWait(driver,2);
		// wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("
		// loginbox-v4__header loginbox-v4__header--signup")));
		WebElement element = driver.findElement(By.id("email--1"));

		element.sendKeys(p.getProperty("validationemail"));
		Thread.sleep(1000);
		String fieldText = element.getText();

		Pattern pattern = Pattern.compile(new String("^(.+)@(.+)$"));

		Matcher matcher = pattern.matcher(fieldText);
		if (matcher.matches()) {
			// if pattern matches
			test.log(LogStatus.PASS, "Test passed- signupFieldValidationEmail");
			TestNGResults.put("13",
					new Object[] { 14d, "signupFieldValidationEmail", "display error message", "Pass" });
			// System.out.println("valid");
		} else {
			// if pattern does not matches

			test.log(LogStatus.FAIL, "Test Failed-  signupFieldValidationEmail");
			TestNGResults.put("13",
					new Object[] { 14d, " signupFieldValidationEmail", "display error message", "Fail" });

		}
	}

	@Test(priority = 15)
	public void signupFieldValidationPassword() throws InterruptedException {
		// String regex = "((?=.*[a-z])(?=.*\\d)(?=.*[A-Z])(?=.*[@#$%!]).{8,40})";
		driver.get(p.getProperty("url"));
		Thread.sleep(1000);
		// to sign up with valid password
		// driver.findElement(By.xpath("//button[contains(text(),'Sign Up')]")).click();
		WebElement clickbutton = (WebElement) new WebDriverWait(driver, 10)
				.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(text(),'Sign Up')]")));
		clickbutton.click();
		WebElement element = driver.findElement(By.xpath("//input[@id='password']"));

		element.sendKeys(p.getProperty("validationpsswrd"));
		String fieldText = element.getText();

		Pattern pattern = Pattern.compile(new String("((?=.*[a-z])(?=.*\\d)(?=.*[A-Z])(?=.*[@#$%!]).{8,40})"));
		Matcher matcher = pattern.matcher(fieldText);
		if (matcher.matches()) {
			// if pattern matches
			test.log(LogStatus.PASS, "Test passed- signupFieldValidationPassword");
			TestNGResults.put("14",
					new Object[] { 15d, "signupFieldValidationPassword", "display error message", "Pass" });

		} else {
			// if pattern does not matches
			test.log(LogStatus.FAIL, "Test Failed- signupFieldValidationPassword");
			TestNGResults.put("14",
					new Object[] { 15d, "signupFieldValidationPassword", "display error message", "Fail" });

		}
	}

	@Test(priority = 16)
	public void signupFieldValidatinOFullName() throws InterruptedException {
		// String regx = "^[a-zA-Z\\s]+$";
		driver.get(p.getProperty("url"));
		Thread.sleep(1000);
		WebElement clickbutton = (WebElement) new WebDriverWait(driver, 10)
				.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(text(),'Sign Up')]")));
		clickbutton.click();
		// to sign up with valid full name
		// driver.findElement(By.xpath("//button[contains(text(),'Sign Up')]")).click();
		WebElement element = driver.findElement(By.xpath("//input[@id='id_fullname']"));

		element.sendKeys(p.getProperty("signupvalidationname"));
		String fieldText = element.getText();
		Pattern pattern = Pattern.compile(new String("^[a-zA-Z\\s]+"));
		Matcher matcher = pattern.matcher(fieldText);
		if (matcher.matches()) {
			// if pattern matches
			test.log(LogStatus.PASS, "Test passed- signupFieldValidatinOFullName");
			TestNGResults.put("15",
					new Object[] { 16d, "signupFieldValidatinOFullName", "display error message", "Pass" });

		} else {
			// if pattern does not matches
			test.log(LogStatus.FAIL, "Test Failed- signupFieldValidatinOFullName");
			TestNGResults.put("15",
					new Object[] { 16d, "signupFieldValidatinOFullName", "display error message", "Fail" });

		}
	}

	@Test(priority = 17)
	public void loginInvalidEmailInvalidPassword() throws IOException, InterruptedException {

		// driver.get("https://www.udemy.com/");
		// driver.findElement(By.xpath("//*[@id=\"udemy\"]/div[2]/div[3]/div[1]/div[4]/div[6]/div/button")).click();
		driver.get(p.getProperty("url"));
		Thread.sleep(1000);
		WebElement clickbutton = (WebElement) new WebDriverWait(driver, 10)
				.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@class='btn btn-quaternary']")));
		clickbutton.click();
		wait = new WebDriverWait(driver, 3);

		// to check for login with invalid username and invalid password
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("#email--1")));
		driver.findElement(By.cssSelector("#email--1")).sendKeys(p.getProperty("email"));
		driver.findElement(By.xpath("//input[@id='id_password']")).sendKeys(p.getProperty("password"));
		driver.findElement(By.xpath("//input[@id='submit-id-submit']")).click();
		wait = new WebDriverWait(driver, 2);
		String expected = wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("//div[contains(@class,'alert alert-danger js-error-alert')]")))
				.getText();
		String actual = driver.findElement(By.xpath("//div[contains(@class,'alert alert-danger js-error-alert')]"))
				.getText();
		if (expected.equalsIgnoreCase(actual)) {
			test.log(LogStatus.PASS, "Test passed- loginInvalidEmailInvalidPassword");
			TestNGResults.put("16",
					new Object[] { 17d, "loginInvalidEmailInvalidPassword", " display error message ", "Pass" });
		} else {
			test.log(LogStatus.FAIL, "Test Failed- loginInvalidEmailInvalidPassword");
			TestNGResults.put("16",
					new Object[] { 17d, "loginInvalidEmailInvalidPassword ", "display error message ", "Fail" });
		}
	}

//login-invalid username and valid password

	@Test(priority = 18)
	public void loginInvalidEmail() throws IOException, TimeoutException, InterruptedException {

		driver.get(p.getProperty("url"));
		Thread.sleep(1000);
		WebElement clickbutton = (WebElement) new WebDriverWait(driver, 10)
				.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@class='btn btn-quaternary']")));
		clickbutton.click();
		wait = new WebDriverWait(driver, 3);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("#email--1")));

// to check if the login page is not accepting an invalid email 
		driver.findElement(By.cssSelector("#email--1")).sendKeys(p.getProperty("invalidemail"));
		driver.findElement(By.xpath("//input[@id='id_password']")).sendKeys(p.getProperty("validpassword"));
		driver.findElement(By.xpath("//input[@id='submit-id-submit']")).click();
//wait = new WebDriverWait(driver,2);
		String expected = wait
				.until(ExpectedConditions
						.visibilityOfElementLocated(By.xpath("//div[@class='alert alert-danger js-error-alert']")))
				.getText();
		String actual = driver.findElement(By.xpath("//div[@class='alert alert-danger js-error-alert']")).getText();

		if (expected.equals(actual)) {
			test.log(LogStatus.PASS, "Test passed- login-invalid username and valid password");
			TestNGResults.put("17", new Object[] { 18d, "login-invalid username and valid password",
					"should display error message ", "Pass" });
		} else {
			test.log(LogStatus.FAIL, "Test Failed- login-invalid username and valid password");
			TestNGResults.put("17", new Object[] { 18d, "login-invalid username and valid password ",
					"should display error message ", "Fail" });
		}
	}

	@Test(priority = 19)
	public void loginFieldValidationEmail() throws InterruptedException {
		// String regex = "^(.+)@(.+)$";

		// to check login page with valid email
		driver.get(p.getProperty("url"));
		Thread.sleep(1000);
		WebElement clickbutton = (WebElement) new WebDriverWait(driver, 10)
				.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@class='btn btn-quaternary']")));
		clickbutton.click();
		/// driver.findElement(By.xpath("//button[@class='btn
		/// btn-quaternary']")).click();
		Thread.sleep(1000);
		/// driver.findElement(By.xpath("//*[@id=\"udemy\"]/div[2]/div[3]/div[1]/div[4]/div[6]/div/button")).click();
		WebElement element = driver.findElement(By.name("email"));

		element.sendKeys(p.getProperty("validationemail"));
		String fieldText = element.getText();

		Pattern pattern = Pattern.compile(new String("^(.+)@(.+)$"));

		Matcher matcher = pattern.matcher(fieldText);
		if (matcher.matches()) {
			// if pattern matches
			test.log(LogStatus.PASS, "Test passed- loginFieldValidationEmail");
			TestNGResults.put("18", new Object[] { 19d, "loginFieldValidationEmail", "display error message", "Pass" });

		} else {
			// if pattern does not matches
			test.log(LogStatus.FAIL, "Test Failed- loginFieldValidationEmail");
			TestNGResults.put("18", new Object[] { 19d, "loginFieldValidationEmail", "display error message", "Fail" });

		}
	}

	@Test(priority = 20)
	public void loginFieldValidationPassword() throws InterruptedException {
		// String regex = "((?=.*[a-z])(?=.*\\d)(?=.*[A-Z])(?=.*[@#$%!]).{8,40})";

		// to check for login page with valid password
		driver.get(p.getProperty("url"));
		Thread.sleep(1000);
		WebElement clickbutton = (WebElement) new WebDriverWait(driver, 10)
				.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@class='btn btn-quaternary']")));
		clickbutton.click();

		// driver.findElement(By.cssSelector("body.ud-app-loader.udemy.pageloaded.ud-app-loaded:nth-child(2)
		// div.main-content-wrapper:nth-child(4)
		// div.c_header.c_header--v6.c_header--desktop.c_header--ia.c_header--ia-.ud-app-loader.ud-app-loaded:nth-child(4)
		// div.c_header__inner div.c_header__right
		// div.dropdown.dropdown--login.ud-component--header-v6--login-button.hidden-xs.hidden-xxs:nth-child(6)
		// div:nth-child(1) > button.btn.btn-quaternary")).click();
		WebElement element = driver.findElement(By.xpath("//input[@id='id_password']"));

		element.sendKeys(p.getProperty("validationpsswrd"));
		String fieldText = element.getText();

		Pattern pattern = Pattern.compile(new String("((?=.*[a-z])(?=.*\\d)(?=.*[A-Z])(?=.*[@#$%!]).{8,40})"));
		Matcher matcher = pattern.matcher(fieldText);
		if (matcher.matches()) {
			// if pattern matches
			test.log(LogStatus.PASS, "Test passed- loginFieldValidationPassword");
			TestNGResults.put("19", new Object[] { 20d, "loginFieldValidationPassword", "display message", "Pass" });

		} else {
			// if pattern does not matches

			test.log(LogStatus.FAIL, "Test Failed- loginFieldValidationPassword");
			TestNGResults.put("19", new Object[] { 20d, "loginFieldValidationPassword", "display message", "Fail" });

		}
	}

	@Test(priority = 21)
	public void close() throws IOException, InterruptedException {
		driver.get(p.getProperty("url"));
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		driver.close();
	}

	@AfterSuite(alwaysRun = true)
	public static void endTest() {
		report.endTest(test);
		report.flush();
	}
}